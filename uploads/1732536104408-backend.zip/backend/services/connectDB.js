(function (connectDB) {

    const mongoose = require("mongoose");
    var Q = require('q');

    var credentials = require('../Config/credentials.js')

    var password = credentials.mongoDbSecrete.password;
    var username = credentials.mongoDbSecrete.userName;
    var dbName = credentials.mongoDbSecrete.dbName;

    var uri = 'mongodb+srv://' + username + ':' + password + '@cluster0.sk38w.mongodb.net/' + dbName + '?retryWrites=true'

    mongoose.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    const db = mongoose.connection;
    db.on("error", console.error.bind(console, "connection error: "));
    db.once("open", function () {
        console.log("Connected successfully");
        return db;
    });

})(module.exports)