const mongoose = require("mongoose");

const UserSchema = new mongoose.Schema({
    User_ID: Number,
    Full_Name: String,
    Email_Address: String,
    password: String
});

const autoIncrementSchema = {
    Table_Name: { type: String },
    Sequence_ID: { type: Number }
}

const userModel = mongoose.model('users', UserSchema);
const autoIncrementModel = mongoose.model('counters', autoIncrementSchema)

module.exports = { userModel, autoIncrementModel }