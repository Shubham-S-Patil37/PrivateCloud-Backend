(function (dbUtility) {
    var db = require('./connectDB')
    var { userModel, autoIncrementModel } = require('../services/schemas')
    var Q = require('q')

    dbUtility.findUser = function (emailAddress) {
        var deferred = Q.defer();
        userModel.find({ Email_Address: emailAddress }).then((data) => { deferred.resolve(Object.values(data)) }).catch((error) => { deferred.reject(error); })
        return deferred.promise;
    }

    dbUtility.getAllUsers = function () {
        var deferred = Q.defer();
        userModel.find({}).then((data) => { deferred.resolve(Object.values(data)); }).catch((error) => { deferred.reject(error); })
        return deferred.promise;
    }


    dbUtility.addUser = (userData) => {
        var deferred = Q.defer();
        dbUtility.getAutoIncrementId('users')
            .then(function (userId) {
                var userId = parseInt(userId.id);

                var userDetails = new userModel({
                    User_ID: userId,
                    Full_Name: userData.fullName,
                    Email_Address: userData.emailAddress,
                    password: userData.password
                });

                userDetails.save((error, doc) => {
                    if (!error) {
                        deferred.resolve({ status: true, message: 'User Inserted' });
                    }
                    else {
                        console.log('Error during record insertion : ' + error);
                        deferred.reject({ status: true, message: error.message });
                    }
                });
            })
            .catch(function (error) {
                deferred.reject({ error })
            })
        return deferred.promise;
    }

    dbUtility.getAutoIncrementId = function (tableName) {
        var deferred = Q.defer();
        var generatedId = 0;
        autoIncrementModel.findOneAndUpdate(
            { Table_Name: tableName },
            { "$inc": { Sequence_ID: 1 } },
            { new: true }, (err, cd) => {
                if (cd == null) {
                    var newVal = new autoIncrementModel({ Table_Name: tableName, Sequence_ID: 1 })
                    newVal.save();
                    generatedId = 1;
                }
                else
                    generatedId = cd.Sequence_ID;
                deferred.resolve({ id: generatedId })
            }
        )
        return deferred.promise;
    }

    dbUtility.updateUserName = function (userDetails) {
        var deferred = Q.defer();

        var myQuery = { Email_Address: userDetails.emailAddress };
        var newValues = {
            $set: { Full_Name: userDetails.fullName }
        };
        userModel.updateMany(myQuery, newValues, function (err, res) {
            if (err)
                deferred.reject(err);
            else
                deferred.resolve('Updated successfully')
        });
        return deferred.promise;
    }
})(module.exports)