(function (userService) {
    var dbUtility = require('./dbUtility')
    var Q = require('q')

    userService.logIn = function (emailAddress, password) {
        console.log('Inside userService.logIn')

        var deferred = Q.defer();
        dbUtility.findUser(emailAddress)
            .then(function (result) {
                if (result.length > 0) {
                    result = Object.values(result[0])

                    result = result[result.length - 1]

                    if (password == result.password) {
                        deferred.resolve({ statusCode: 200, status: "Authorized", message: "Welcome to dashboard" })
                    }
                    else
                        deferred.resolve({ statusCode: 401, status: "Unauthorized", message: "Unauthorized to access, Please check your credentials" })
                }
                else
                    deferred.resolve({ statusCode: 401, status: "Unauthorized", message: "Unauthorized to access, Please check your credentials" })
            })
            .catch(function (error) {
                console.log('Error in ' + error)
                deferred.reject()
            })
        return deferred.promise;
    }

    userService.getAllSystemUser = function () {
        console.log('Inside userService.getAllSystemUser')

        var deferred = Q.defer();
        dbUtility.getAllUsers()
            .then(function (result) {
                if (result.length == 0) {
                    deferred.resolve({ statusCode: 200, status: "Authorized", message: "No user founded !", data: [] })
                }
                else
                    deferred.resolve({ statusCode: 401, status: "Unauthorized", message: "User founded.", data: result })
            })
            .catch(function (error) {
                console.log('Error in ' + error)
                deferred.reject()
            })
        return deferred.promise;
    }

    userService.addUser = function (userData) {
        var deferred = Q.defer();

        dbUtility.findUser(userData.emailAddress)
            .then(function (response) {
                if (response.length > 0) {
                    deferred.resolve({ message: "Email address already exist. Ues different email address to register." });
                }
                else {
                    dbUtility.addUser(userData)
                        .then(function (userData) {
                            deferred.resolve({ message: "User added." });
                        })
                        .catch(function (err) {
                            console.log('error ' + err)
                            deferred.reject({ message: err.message });
                        })
                }
            })
            .catch(function (err) {
                console.log('error ' + err)
                deferred.reject({ status: false, message: err.message });
            })

        return deferred.promise;
    }

    userService.updateUserName = function (userData) {
        var deferred = Q.defer();
        dbUtility.updateUserName(userData)
            .then(function (user) {
                deferred.resolve(user);
            })
            .catch(function (err) {
                deferred.reject(err.message);
            })
        return deferred.promise;
    }
})(module.exports)