var express = require('express');
var app = express();
var http = require('http');
var bodyParser = require('body-parser');

var cors = require('cors')
var port = process.env.port || 8000;
app.use(express.static(__dirname + '/'));
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())
app.use(express.json({ limit: '50mb' }));
app.use(cors());
var server = http.createServer(app);
server.listen(port, () => console.log('theBox Running at port : ' + port));

var userService = require('./services/userService');

app.get('/testEndPoint', function (req, res) { res.send({ "response": "test endpoint" }); });

app.get('/userAuth', function (req, res) { userService.logIn(req.query.emailAddress, req.query.password).then(response => res.status(response.statusCode).send(response)).catch(err => res.status(500).send(err)) });

app.get('/getAllUser', function (req, res) { userService.getAllSystemUser(req.query.emailAddress, req.query.password).then(response => res.send(response)).catch(err => res.status(500).send(err)) })

app.post('/addUser', function (req, res) { userService.addUser(req.body).then((data) => { res.send(data) }).catch((error) => { res.status(500).send(error) }) })

app.post('/updateUserName', function (req, res) { userService.updateUserName(req.body).then((data) => { res.send(data) }).catch((error) => { res.status(500).send(error) }) })