module.exports = {
    mongoDbSecrete: {
        "userName": "Shubham_Temp",
        "password": "7XgkLb59ZdMYvrJu",
        "dbName": "Student"
    }
}